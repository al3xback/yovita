$(document).ready(function(){
	//banner slider
	if($('.bannerSlide').length>0){
		var owlBanner = $('.bannerSlide');
		owlBanner.owlCarousel({
			autoPlay: true,
			items : 1,
			itemsDesktop : [1199,1],
			itemsDesktopSmall : [980,1],
			itemsTablet: [768,1],
			slideSpeed: 800,
			pagination : true
		});
	}
	if($('.vendorSlide').length>0){
		var owlVendor = $('.vendorSlide');
		owlVendor.owlCarousel({
			autoPlay: false,
			items : 4,
			itemsDesktop : [1199,4],
			itemsDesktopSmall : [980,4],
			itemsTablet: [768,2],
			slideSpeed: 800,
			pagination : false,
			afterAction: function(){
				if ( this.itemsAmount > this.visibleItems.length ) {
					$(".nextBtn").show();
					$(".prevBtn").show();
					$(".nextBtn").removeClass('disabled');
					$(".prevBtn").removeClass('disabled');
					if ( this.currentItem == 0 ) {
						$(".prevBtn").addClass('disabled');
					}
					if ( this.currentItem == this.maximumItem ) {
						$(".nextBtn").addClass('disabled');
					}
				} else {
					$(".nextBtn").hide();
					$(".prevBtn").hide();
				}
			}
		});
		$(".nextBtn").click(function(){
			owlVendor.trigger('owl.next');
			return false;
		})
		$(".prevBtn").click(function(){
			owlVendor.trigger('owl.prev');
			return false;
		})
	}
	//select
	if($('select').length > 0){
		$("select").selectOrDie({
			placeholderOption:false,
			onChange: function() { 
			}
		});
	}

	if($(window).scrollTop() > 100){
		$('#logo').addClass('animated zoomOutLeft');
	}

	$('section').css({
 		'padding-top':'250px'
 	});
	
	$('#changePass').change(function(){
		if($('#changePass').is(':checked')){
			$('input[type="password"]').removeAttr('disabled');
		}
		else{
			$('input[type="password"]').attr('disabled','disabled');
		}
	})

	$('.inboxMessageBox input[type="checkbox"]').change(function(){
		if($(this).is(':checked')){
			$(this).parents(".inboxMessageBox").addClass('active');
		}
		else{
			$(this).closest(".inboxMessageBox").removeClass('active');
		}
	})

	//scrollpane
	if($('.contentScroll').length>0){
		if($(window).width()>768){
			$('.contentScroll').each(
				function()
				{
					$(this).jScrollPane(
						{
							verticalDragMinHeight: 20,
							verticalDragMaxHeight: 20,
							autoReinitialise: true
						}
					);
					var api = $(this).data('jsp');
					var throttleTimeout;
					$(window).bind(
						'resize',
						function()
						{
							if($(window).width()>720){
								if (!throttleTimeout) {
									throttleTimeout = setTimeout(
										function()
										{
											api.reinitialise();
											throttleTimeout = null;
										},
										50
									);
								}
							}
						}
					);
				}
			);
		}
	}

	if($('.dob').length > 0){
		$( ".dob" ).datepicker({
			 changeMonth: true,
			 changeYear: true,
			 yearRange: "-100:+0",
			 defaultDate: -10220
		});
	}	
});

$(window).bind('scroll', function(){
	if($(window).scrollTop() > 100){
		$('#logo').addClass('zoomOutLeft');
		$('.navCon').addClass('transformNav');
		$('header').addClass('transform');
		setTimeout(function(){
			// $('section').css({
			// 	'padding-top':$('header').outerHeight(true) + 100
			// });
			
		},1300);
	}
	else{
		$('#logo').removeClass('zoomOutLeft');
		$('.navCon').removeClass('transformNav');
		$('header').removeClass('transform');
		setTimeout(function(){
			// $('section').css({
			// 	'padding-top':$('header').outerHeight(true)
			// });

		},1300);
	}
	
	
});

$(window).bind('resize', function(){
	
});

$(window).bind('load', function(){
	// setTimeout(function(){
	// 	$('section').css({
	// 		'padding-top':$('header').outerHeight(true)
	// 	});
	// },700);
});
